// Definindo os tipos usados pelo contexto de autenticação

export interface User {
  email: string;
  isAdmin: boolean;
}

export interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: User | null;
  token: string | null;
  loginWithRedirect: () => Promise<void>;
  logout: () => void;
}


// Re-exportar outros tipos
// Usando try-catch para importação, caso os arquivos não existam
// ou tenham algum problema, a aplicação não quebra
export * from './Note.js';
export * from './Tool.js';
